# Changes — V2 Secure

- New independent Python implementation based on the exposed administrative commands and SQLite schemas of Telthuon-sessons.
- Retains management command names and database schema for admins and allowlisted users.
- Adds Arabic inline menu, permission checks on callback actions, private chat restriction, flood limiting, owner DB backup, administrative audit trail, and summaries.
- Avoids collecting Telegram OTP/2FA credentials or sending `StringSession` strings through chatbot messages; session creation is now opt-in and local.
- Adds configuration examples, .gitignore, migration instructions and unit tests.
- No production bot token, session, Telegram user login or database records included.
