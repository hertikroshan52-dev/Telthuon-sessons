"""SQLite storage compatible with the original admins/allowed_users tables.

This module never stores OTPs, passwords, Telegram session strings or phone numbers.
"""
from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


class Storage:
    def __init__(self, path: str | Path, owner_id: int):
        if owner_id <= 0:
            raise ValueError("owner_id must be positive")
        self.path = Path(path)
        self.owner_id = owner_id
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.initialize()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.path), timeout=15)
        conn.execute("PRAGMA busy_timeout = 15000")
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def initialize(self) -> None:
        with self._connect() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS admins (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    full_name TEXT,
                    added_by INTEGER,
                    added_date DATETIME DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS allowed_users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    full_name TEXT,
                    added_by INTEGER,
                    added_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                    is_active INTEGER DEFAULT 1
                );
                CREATE TABLE IF NOT EXISTS audit_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    actor_id INTEGER NOT NULL,
                    action TEXT NOT NULL,
                    target_id INTEGER,
                    created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_audit_time ON audit_events(created_at);
            """)
            conn.execute(
                "INSERT OR IGNORE INTO admins (user_id, username, full_name, added_by) VALUES (?, ?, ?, ?)",
                (self.owner_id, "OWNER", "OWNER", self.owner_id),
            )
        try:
            self.path.chmod(0o600)
        except OSError:
            pass

    def is_owner(self, user_id: int) -> bool:
        return user_id == self.owner_id

    def is_admin(self, user_id: int) -> bool:
        if self.is_owner(user_id):
            return True
        with self._connect() as conn:
            return conn.execute("SELECT 1 FROM admins WHERE user_id = ?", (user_id,)).fetchone() is not None

    def is_allowed(self, user_id: int, public_mode: bool = False) -> bool:
        if self.is_admin(user_id) or public_mode:
            return True
        with self._connect() as conn:
            return conn.execute(
                "SELECT 1 FROM allowed_users WHERE user_id = ? AND is_active = 1", (user_id,)
            ).fetchone() is not None

    def add_user(self, user_id: int, added_by: int) -> None:
        self._validate_id(user_id)
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO allowed_users(user_id, username, full_name, added_by, is_active)
                VALUES(?, '', '', ?, 1)
                ON CONFLICT(user_id) DO UPDATE SET is_active = 1, added_by = excluded.added_by
            """, (user_id, added_by))
        self.audit(added_by, "user_added", user_id)

    def remove_user(self, user_id: int, actor: int) -> bool:
        self._validate_id(user_id)
        if self.is_admin(user_id):
            return False
        with self._connect() as conn:
            changed = conn.execute(
                "UPDATE allowed_users SET is_active = 0 WHERE user_id = ? AND is_active = 1", (user_id,)
            ).rowcount
        if changed:
            self.audit(actor, "user_disabled", user_id)
        return bool(changed)

    def add_admin(self, user_id: int, actor: int) -> None:
        self._validate_id(user_id)
        if actor != self.owner_id:
            raise PermissionError("Only owner can edit admins")
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO admins(user_id, username, full_name, added_by)
                VALUES(?, '', '', ?)
                ON CONFLICT(user_id) DO UPDATE SET added_by = excluded.added_by
            """, (user_id, actor))
        self.audit(actor, "admin_added", user_id)

    def remove_admin(self, user_id: int, actor: int) -> bool:
        self._validate_id(user_id)
        if actor != self.owner_id:
            raise PermissionError("Only owner can edit admins")
        if user_id == self.owner_id:
            return False
        with self._connect() as conn:
            changed = conn.execute("DELETE FROM admins WHERE user_id = ?", (user_id,)).rowcount
        if changed:
            self.audit(actor, "admin_removed", user_id)
        return bool(changed)

    def list_users(self, limit: int = 80) -> list[tuple]:
        with self._connect() as conn:
            return conn.execute("""
                SELECT user_id, COALESCE(username, ''), COALESCE(full_name, '')
                FROM allowed_users WHERE is_active = 1 ORDER BY added_date, user_id LIMIT ?
            """, (limit,)).fetchall()

    def list_admins(self, limit: int = 80) -> list[tuple]:
        with self._connect() as conn:
            return conn.execute("""
                SELECT user_id, COALESCE(username, ''), COALESCE(full_name, '')
                FROM admins ORDER BY added_date, user_id LIMIT ?
            """, (limit,)).fetchall()

    def stats(self) -> dict[str, int]:
        with self._connect() as conn:
            return {
                "admins": conn.execute("SELECT COUNT(*) FROM admins").fetchone()[0],
                "users": conn.execute("SELECT COUNT(*) FROM allowed_users WHERE is_active = 1").fetchone()[0],
                "disabled": conn.execute("SELECT COUNT(*) FROM allowed_users WHERE is_active = 0").fetchone()[0],
                "audit_events": conn.execute("SELECT COUNT(*) FROM audit_events").fetchone()[0],
            }

    def audit(self, actor_id: int, action: str, target_id: Optional[int] = None) -> None:
        # Fixed event names only; never accept raw user messages, secret codes or session strings.
        permitted = {"user_added", "user_disabled", "admin_added", "admin_removed", "backup_created"}
        if action not in permitted:
            raise ValueError("Unsupported audit event")
        stamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO audit_events(actor_id, action, target_id, created_at) VALUES (?, ?, ?, ?)",
                (actor_id, action, target_id, stamp),
            )
            conn.execute("""
                DELETE FROM audit_events WHERE id NOT IN
                (SELECT id FROM audit_events ORDER BY id DESC LIMIT 5000)
            """)

    def recent_activity(self, limit: int = 10) -> list[tuple]:
        with self._connect() as conn:
            return conn.execute("""
                SELECT created_at, actor_id, action, target_id
                FROM audit_events ORDER BY id DESC LIMIT ?
            """, (min(max(limit, 1), 50),)).fetchall()

    def backup(self, path: str | Path) -> Path:
        dest = Path(path)
        dest.parent.mkdir(parents=True, exist_ok=True)
        # SQLite online backup includes the committed state and avoids partial file copies.
        source_conn = self._connect()
        try:
            with sqlite3.connect(str(dest)) as dest_conn:
                source_conn.backup(dest_conn)
        finally:
            source_conn.close()
        try:
            dest.chmod(0o600)
        except OSError:
            pass
        return dest

    @staticmethod
    def _validate_id(user_id: int) -> None:
        if not isinstance(user_id, int) or user_id <= 0:
            raise ValueError("Telegram user ID must be positive")
