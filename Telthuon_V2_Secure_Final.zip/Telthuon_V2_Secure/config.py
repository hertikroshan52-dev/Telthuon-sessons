"""Application configuration. No secrets are stored in source control."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv


@dataclass(frozen=True)
class Config:
    bot_token: str
    owner_id: int
    public_mode: bool
    database_path: Path


def read_config() -> Config:
    load_dotenv(override=False)
    token = os.getenv("BOT_TOKEN", "").strip()
    raw_owner = os.getenv("OWNER_ID", "").strip()
    if not token or token.startswith("YOUR_"):
        raise SystemExit("BOT_TOKEN is missing. Set it in .env or the environment.")
    try:
        owner_id = int(raw_owner)
        if owner_id <= 0:
            raise ValueError
    except ValueError:
        raise SystemExit("OWNER_ID must be a positive Telegram user ID.") from None
    public = os.getenv("PUBLIC_MODE", "0").strip() == "1"
    data_dir = Path(os.getenv("DATA_DIR", "./data")).expanduser().resolve()
    data_dir.mkdir(parents=True, exist_ok=True)
    os.chmod(data_dir, 0o700)
    db_raw = os.getenv("DB_NAME", "").strip()
    db_path = Path(db_raw).expanduser().resolve() if db_raw else data_dir / "session_bot.db"
    db_path.parent.mkdir(parents=True, exist_ok=True)
    return Config(token, owner_id, public, db_path)
