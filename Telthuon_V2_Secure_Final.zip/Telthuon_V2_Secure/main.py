"""Telthuon V2: Telegram bot administration with backwards-compatible storage.

Sensitive Telegram account login is deliberately handled only by local_session.py.
Do not request OTP, 2FA passwords, or StringSession tokens in chat.
"""
from __future__ import annotations

import logging
import os
import tempfile
import time
from collections import defaultdict, deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.constants import ChatType
from telegram.ext import Application, CallbackQueryHandler, CommandHandler, ContextTypes, MessageHandler, filters

from config import Config, read_config
from storage import Storage

LOG = logging.getLogger("telthuon_v2")


class RateLimiter:
    """Simple per-process anti-flood protection for menus and commands."""

    def __init__(self, limit: int = 20, window_seconds: int = 60):
        self.limit = limit
        self.window = window_seconds
        self.events: dict[int, deque[float]] = defaultdict(deque)

    def allow(self, user_id: int) -> bool:
        now = time.monotonic()
        q = self.events[user_id]
        while q and now - q[0] > self.window:
            q.popleft()
        if len(q) >= self.limit:
            return False
        q.append(now)
        return True


class BotService:
    def __init__(self, config: Config, store: Storage):
        self.config = config
        self.store = store
        self.limiter = RateLimiter()

    async def guard(self, update: Update, role: str = "user") -> bool:
        user = update.effective_user
        chat = update.effective_chat
        if not user or not chat:
            return False
        if chat.type != ChatType.PRIVATE:
            if update.callback_query:
                await update.callback_query.answer("افتح البوت في محادثة خاصة.", show_alert=True)
            elif update.effective_message:
                await update.effective_message.reply_text("🔒 الأوامر متاحة في المحادثة الخاصة فقط.")
            return False
        if not self.limiter.allow(user.id):
            if update.callback_query:
                await update.callback_query.answer("⏳ طلبات كثيرة، حاول لاحقًا.", show_alert=True)
            elif update.effective_message:
                await update.effective_message.reply_text("⏳ طلبات كثيرة، حاول لاحقًا.")
            return False
        if role == "owner":
            permitted = self.store.is_owner(user.id)
        elif role == "admin":
            permitted = self.store.is_admin(user.id)
        else:
            permitted = self.store.is_allowed(user.id, self.config.public_mode)
        if not permitted:
            if update.callback_query:
                await update.callback_query.answer("❌ ليست لديك صلاحية.", show_alert=True)
            elif update.effective_message:
                await update.effective_message.reply_text("❌ ليست لديك صلاحية. تواصل مع المشرف لإضافتك.")
            return False
        return True

    def buttons(self, user_id: int) -> InlineKeyboardMarkup:
        rows = [
            [InlineKeyboardButton("🔐 إنشاء جلسة بأمان", callback_data="guide")],
            [InlineKeyboardButton("🆔 آيدي حسابي", callback_data="myid"),
             InlineKeyboardButton("ℹ️ المساعدة", callback_data="help")],
        ]
        if self.store.is_admin(user_id):
            rows.append([InlineKeyboardButton("👥 المستخدمون", callback_data="users"),
                         InlineKeyboardButton("📊 الإحصائيات", callback_data="stats")])
            rows.append([InlineKeyboardButton("📜 سجل الإدارة", callback_data="logs"),
                         InlineKeyboardButton("🟢 حالة البوت", callback_data="status")])
        if self.store.is_owner(user_id):
            rows.append([InlineKeyboardButton("👮 المشرفون", callback_data="admins")])
        return InlineKeyboardMarkup(rows)

    @staticmethod
    def back_button() -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup([[InlineKeyboardButton("↩️ القائمة الرئيسية", callback_data="home")]])

    async def respond(self, update: Update, message: str, keyboard: InlineKeyboardMarkup | None = None) -> None:
        if update.callback_query:
            query = update.callback_query
            await query.answer()
            try:
                await query.edit_message_text(message, reply_markup=keyboard)
            except Exception as exc:
                # A menu may be unchanged; avoid printing sensitive Telegram API errors.
                if type(exc).__name__ != "BadRequest":
                    LOG.warning("Cannot edit menu; exception=%s", type(exc).__name__)
        elif update.effective_message:
            await update.effective_message.reply_text(message, reply_markup=keyboard)

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.guard(update):
            return
        await self.respond(update,
            "👋 أهلًا بك في Telthuon V2\n\n"
            "✅ لوحة إدارة محسّنة مع المحافظة على قاعدة بيانات المستخدمين والمشرفين.\n"
            "🔐 استخراج الجلسات يتم على جهازك مباشرة، دون إرسال رمز التحقق أو الجلسة داخل محادثة بوت.\n\n"
            "اختر من القائمة:",
            self.buttons(update.effective_user.id))

    async def myid(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        # This command is useful for requesting access even when not on the allowlist.
        if not update.effective_chat or update.effective_chat.type != ChatType.PRIVATE:
            return
        if not update.effective_user:
            return
        if not self.limiter.allow(update.effective_user.id):
            return
        user = update.effective_user
        name = user.full_name[:100]
        await self.respond(update, f"🆔 آيديك: {user.id}\n👤 الاسم: {name}", self.back_button())

    def help_text(self, actor: int) -> str:
        text = (
            "📌 أوامر البوت:\n"
            "/start — القائمة الرئيسية\n"
            "/myid — آيدي حسابك\n"
            "/help — شرح الأوامر\n"
            "/cancel — الرجوع إلى القائمة\n"
            "/session — تعليمات إنشاء الجلسة على جهازك\n"
        )
        if self.store.is_admin(actor):
            text += (
                "\n👮 أوامر المشرف:\n"
                "/adduser ID — إضافة/إعادة تفعيل مستخدم\n"
                "/deluser ID — تعطيل مستخدم\n"
                "/users — المستخدمون النشطون\n"
                "/stats — الإحصائيات\n"
                "/logs — سجل الإدارة\n"
                "/status — حالة الخدمة\n"
            )
        if self.store.is_owner(actor):
            text += (
                "\n👑 أوامر المالك:\n"
                "/addadmin ID — إضافة مشرف\n"
                "/deladmin ID — حذف مشرف\n"
                "/admins — قائمة المشرفين\n"
                "/backup — نسخة قاعدة البيانات (إدارية فقط)\n"
            )
        text += "\n🔒 لا ترسل إلى البوت رموز الدخول أو كلمات المرور أو StringSession."
        return text

    async def help(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.guard(update):
            return
        await self.respond(update, self.help_text(update.effective_user.id), self.back_button())

    async def guide(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.guard(update):
            return
        await self.respond(update, (
            "🔐 إنشاء جلسة Telethon الخاصة بك:\n\n"
            "1) ثبّت Python والمتطلبات من requirements.txt على جهازك.\n"
            "2) أضف API_ID وAPI_HASH إلى ملف .env المحلي.\n"
            "3) شغّل: python local_session.py\n"
            "4) أدخل رقمك ورمزك وكلمة مرور التحقق بخطوتين على جهازك فقط.\n"
            "5) تُحفظ الجلسة في private_sessions/ بصلاحيات وصول محدودة.\n\n"
            "⚠️ الجلسة تعادل كلمة مرور. لا ترسلها عبر البوت أو ترفعها إلى GitHub."
        ), self.back_button())

    @staticmethod
    def _target_id(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int | None:
        raw = None
        if context.args:
            raw = context.args[0].strip()
        elif update.effective_message and update.effective_message.reply_to_message:
            sender = update.effective_message.reply_to_message.from_user
            if sender:
                return sender.id
        if not raw:
            return None
        try:
            value = int(raw)
            return value if value > 0 else None
        except ValueError:
            return None

    async def adduser(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.guard(update, "admin"):
            return
        actor = update.effective_user.id
        target = self._target_id(update, context)
        if not target:
            await self.respond(update, "الاستخدام: /adduser USER_ID")
            return
        self.store.add_user(target, actor)
        await self.respond(update, f"✅ تمت إضافة/تفعيل المستخدم: {target}")

    async def deluser(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.guard(update, "admin"):
            return
        actor = update.effective_user.id
        target = self._target_id(update, context)
        if not target:
            await self.respond(update, "الاستخدام: /deluser USER_ID")
            return
        ok = self.store.remove_user(target, actor)
        if ok:
            await self.respond(update, f"✅ تم تعطيل المستخدم: {target}")
        else:
            await self.respond(update, "ℹ️ المستخدم غير مفعّل أو حساب إداري محمي.")

    async def addadmin(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.guard(update, "owner"):
            return
        target = self._target_id(update, context)
        if not target:
            await self.respond(update, "الاستخدام: /addadmin USER_ID")
            return
        self.store.add_admin(target, update.effective_user.id)
        await self.respond(update, f"✅ تمت إضافة المشرف: {target}")

    async def deladmin(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.guard(update, "owner"):
            return
        target = self._target_id(update, context)
        if not target:
            await self.respond(update, "الاستخدام: /deladmin USER_ID")
            return
        ok = self.store.remove_admin(target, update.effective_user.id)
        await self.respond(update, f"✅ تم حذف المشرف: {target}" if ok else "❌ لا يمكن حذف المالك أو المشرف غير موجود.")

    async def users(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.guard(update, "admin"):
            return
        rows = self.store.list_users()
        stats = self.store.stats()
        content = "👥 المستخدمون النشطون: " + str(stats["users"]) + "\n\n"
        content += "\n".join(f"• {row[0]}" for row in rows) if rows else "لا يوجد مستخدمون مضافون."
        if stats["users"] > len(rows):
            content += "\n... القائمة تعرض أول 80 مستخدمًا."
        await self.respond(update, content, self.back_button())

    async def admins(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.guard(update, "owner"):
            return
        rows = self.store.list_admins()
        stats = self.store.stats()
        content = "👮 المشرفون: " + str(stats["admins"]) + "\n\n"
        content += "\n".join(f"{'👑' if row[0] == self.config.owner_id else '•'} {row[0]}" for row in rows)
        if stats["admins"] > len(rows):
            content += "\n... القائمة تعرض أول 80 مشرفًا."
        await self.respond(update, content, self.back_button())

    async def stats(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.guard(update, "admin"):
            return
        x = self.store.stats()
        await self.respond(update, (
            "📊 إحصائيات لوحة الإدارة\n\n"
            f"👮 المشرفون: {x['admins']}\n"
            f"✅ المستخدمون النشطون: {x['users']}\n"
            f"🚫 المستخدمون المعطلون: {x['disabled']}\n"
            f"📜 العمليات الإدارية المسجلة: {x['audit_events']}\n\n"
            "ℹ️ لا يتم حفظ رموز التحقق أو الجلسات في قاعدة البيانات."
        ), self.back_button())

    async def logs(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.guard(update, "admin"):
            return
        events = self.store.recent_activity(12)
        labels = {
            'user_added': 'إضافة مستخدم', 'user_disabled': 'تعطيل مستخدم',
            'admin_added': 'إضافة مشرف', 'admin_removed': 'حذف مشرف',
            'backup_created': 'نسخة احتياطية'
        }
        txt = "📜 آخر العمليات الإدارية (بدون بيانات دخول):\n\n"
        txt += "\n".join(
            f"• {t[:16].replace('T', ' ')} | {labels.get(a, a)} | {target or '-'} | بواسطة {actor}"
            for t, actor, a, target in events
        ) if events else "لا توجد عمليات مسجلة بعد."
        await self.respond(update, txt, self.back_button())

    async def status(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.guard(update, "admin"):
            return
        try:
            self.store.stats()
            db = "✅ متصلة"
        except Exception:
            db = "❌ خطأ"
        await self.respond(update, (
            "🟢 حالة لوحة Telthuon V2\n"
            f"قاعدة البيانات: {db}\n"
            f"وضع الوصول: {'عام' if self.config.public_mode else 'خاص'}\n"
            "رموز الدخول والجلسات داخل البوت: غير مدعومة لأسباب أمنية"
        ), self.back_button())

    async def backup(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.guard(update, "owner"):
            return
        # Temporary file is deleted after sending. There are no account sessions in the DB.
        fd, tmp_name = tempfile.mkstemp(prefix="telthuon_", suffix=".sqlite")
        os.close(fd)
        try:
            self.store.audit(update.effective_user.id, "backup_created")
            self.store.backup(tmp_name)
            name = f"telthuon_admin_backup_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.sqlite"
            with open(tmp_name, 'rb') as source:
                await context.bot.send_document(
                    chat_id=update.effective_chat.id,
                    document=source,
                    filename=name,
                    caption="📁 نسخة احتياطية لقاعدة بيانات المستخدمين والمشرفين. احتفظ بها في مكان آمن."
                )
        finally:
            Path(tmp_name).unlink(missing_ok=True)

    async def cancel(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        await self.start(update, context)

    async def unknown_text(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.guard(update):
            return
        await self.respond(update, "استخدم /start لفتح القائمة. 🔒 لا ترسل هنا رمز الدخول أو كلمة مرور أو جلسة.")

    async def callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not update.callback_query:
            return
        action = update.callback_query.data or ""
        dispatch = {
            "home": self.start, "myid": self.myid, "help": self.help,
            "guide": self.guide, "users": self.users, "admins": self.admins,
            "stats": self.stats, "logs": self.logs, "status": self.status,
        }
        func = dispatch.get(action)
        if func is None:
            await update.callback_query.answer("الزر غير معروف", show_alert=True)
            return
        await func(update, context)


def build_application(config: Config, storage: Storage) -> Application:
    service = BotService(config, storage)
    app = Application.builder().token(config.bot_token).concurrent_updates(False).build()
    for name, handler in {
        "start": service.start, "cancel": service.cancel,
        "myid": service.myid, "help": service.help, "session": service.guide,
        "adduser": service.adduser, "deluser": service.deluser,
        "users": service.users, "addadmin": service.addadmin,
        "deladmin": service.deladmin, "admins": service.admins,
        "stats": service.stats, "logs": service.logs,
        "status": service.status, "backup": service.backup,
    }.items():
        app.add_handler(CommandHandler(name, handler))
    app.add_handler(CallbackQueryHandler(service.callback, pattern=r"^(home|myid|help|guide|users|admins|stats|logs|status)$"))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND & filters.ChatType.PRIVATE, service.unknown_text))

    async def handle_error(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
        LOG.error("Unhandled error (%s)", type(context.error).__name__)
        if isinstance(update, Update) and update.effective_chat and update.effective_chat.type == ChatType.PRIVATE:
            try:
                if update.callback_query:
                    await update.callback_query.answer("حدث خطأ، حاول لاحقًا.", show_alert=True)
                elif update.effective_message:
                    await update.effective_message.reply_text("حدث خطأ غير متوقع. حاول مجددًا.")
            except Exception:
                pass

    app.add_error_handler(handle_error)
    return app


def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )
    # Avoid writing Bot API tokens into HTTP client/debug logs.
    for name in ("httpx", "httpcore", "telegram", "telethon"):
        logging.getLogger(name).setLevel(logging.WARNING)
    config = read_config()
    storage = Storage(config.database_path, config.owner_id)
    app = build_application(config, storage)
    LOG.info("Telthuon V2 started, owner=%s, public=%s", config.owner_id, config.public_mode)
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
