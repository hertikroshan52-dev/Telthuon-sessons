import sqlite3
import tempfile
import unittest
from pathlib import Path

from storage import Storage


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / "session_bot.db"
        self.store = Storage(self.path, 111)

    def tearDown(self):
        self.temp.cleanup()

    def test_permissions(self):
        self.assertTrue(self.store.is_owner(111))
        self.assertTrue(self.store.is_admin(111))
        self.assertFalse(self.store.is_allowed(222))
        self.store.add_user(222, 111)
        self.assertTrue(self.store.is_allowed(222))
        self.assertEqual(len(self.store.list_users()), 1)
        self.assertTrue(self.store.remove_user(222, 111))
        self.assertFalse(self.store.is_allowed(222))
        self.store.add_user(222, 111)
        self.assertTrue(self.store.is_allowed(222))

    def test_only_owner_changes_admins(self):
        with self.assertRaises(PermissionError):
            self.store.add_admin(333, 222)
        self.store.add_admin(333, 111)
        self.assertTrue(self.store.is_admin(333))
        self.assertFalse(self.store.remove_admin(111, 111))
        self.assertFalse(self.store.remove_user(333, 111))
        with self.assertRaises(PermissionError):
            self.store.remove_admin(333, 333)
        self.assertTrue(self.store.remove_admin(333, 111))

    def test_original_database_migration(self):
        path = Path(self.temp.name) / "legacy.db"
        with sqlite3.connect(path) as conn:
            conn.executescript("""
                CREATE TABLE admins (user_id INTEGER PRIMARY KEY, username TEXT,
                    full_name TEXT, added_by INTEGER,
                    added_date DATETIME DEFAULT CURRENT_TIMESTAMP);
                CREATE TABLE allowed_users (user_id INTEGER PRIMARY KEY,
                    username TEXT, full_name TEXT, added_by INTEGER,
                    added_date DATETIME DEFAULT CURRENT_TIMESTAMP, is_active INTEGER DEFAULT 1);
                INSERT INTO allowed_users(user_id,username,full_name,added_by,is_active)
                    VALUES (555,'@test','Test Name',111,1);
            """)
        migrated = Storage(path, 111)
        self.assertTrue(migrated.is_allowed(555))
        self.assertEqual(migrated.list_users()[0][1], '@test')
        migrated.add_admin(444, 111)
        self.assertTrue(migrated.is_admin(444))

    def test_stats_and_backup(self):
        self.store.add_user(222, 111)
        stats = self.store.stats()
        self.assertEqual(stats['admins'], 1)
        self.assertEqual(stats['users'], 1)
        self.assertEqual(stats['audit_events'], 1)
        backup_path = self.store.backup(Path(self.temp.name) / "backup.db")
        with sqlite3.connect(backup_path) as conn:
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM allowed_users").fetchone()[0], 1)

    def test_audit_rejects_secrets_and_invalid_ids(self):
        with self.assertRaises(ValueError):
            self.store.audit(111, 'password=secret')
        with self.assertRaises(ValueError):
            self.store.add_user(-1, 111)


if __name__ == '__main__':
    unittest.main()
