"""Generate a Telethon StringSession locally, never through a third-party bot.

Run only on a device you control. The session is written to a private local file.
"""
from __future__ import annotations

import getpass
import os
import re
from datetime import datetime, timezone
from pathlib import Path

from dotenv import load_dotenv


def main() -> None:
    try:
        from telethon.sync import TelegramClient
        from telethon.sessions import StringSession
        from telethon.errors import FloodWaitError, PhoneNumberInvalidError
    except ImportError:
        raise SystemExit("Install dependencies first: pip install -r requirements.txt") from None

    load_dotenv(override=False)
    raw_id = os.getenv("API_ID", "").strip()
    api_hash = os.getenv("API_HASH", "").strip()
    if not raw_id.isdigit() or not api_hash:
        raise SystemExit("Set API_ID and API_HASH in your .env file first.")
    api_id = int(raw_id)
    print("إنشاء جلسة محلية لحساب تيليجرام الذي تملكه فقط.")
    print("لا ترسل الجلسة أو رمز الدخول أو كلمة المرور إلى بوت أو شخص آخر.")
    phone = input("رقمك بالصيغة الدولية (+...): ").strip()
    if not re.fullmatch(r"\+[1-9][0-9]{6,14}", phone):
        raise SystemExit("صيغة رقم الهاتف غير صحيحة.")

    client = TelegramClient(StringSession(), api_id, api_hash)
    try:
        client.start(
            phone=lambda: phone,
            code_callback=lambda: getpass.getpass("رمز التحقق (إدخال مخفي): "),
            password=lambda: getpass.getpass("كلمة مرور التحقق بخطوتين (إدخال مخفي): "),
            max_attempts=3,
        )
        me = client.get_me()
        if not me:
            raise RuntimeError("Could not verify the account after login.")
        confirmation = input("تم تسجيل الدخول. حفظ جلسة الحساب محليًا؟ اكتب yes: ").strip()
        if confirmation != "yes":
            print("تم الإلغاء؛ لن يتم حفظ الجلسة.")
            return
        secret = client.session.save()
        if not secret:
            raise RuntimeError("Session was empty.")
        folder = Path("private_sessions").resolve()
        folder.mkdir(parents=True, exist_ok=True)
        try:
            folder.chmod(0o700)
        except OSError:
            pass
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        path = folder / f"telethon_{timestamp}_{me.id}.txt"
        fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(secret + "\n")
        print("✅ تم حفظ الجلسة على جهازك فقط:")
        print(path)
        print("⚠️ تعامل مع الملف مثل كلمة المرور ولا ترفعه إلى GitHub أو ترسله في محادثة.")
    except (FloodWaitError, PhoneNumberInvalidError) as exc:
        print(f"تعذر تسجيل الدخول مؤقتًا: {type(exc).__name__}")
    except (KeyboardInterrupt, EOFError):
        print("\nتم الإلغاء.")
    finally:
        try:
            client.disconnect()
        except Exception:
            pass


if __name__ == "__main__":
    main()
